//
//  FAQViewController.h
//  TravelHouseUK
//
//  Created by AR on 06/01/2014.
//
//

#import <UIKit/UIKit.h>

@interface FAQViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIScrollView *faqScroller;
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *borderedlayer;

- (IBAction)goback:(id)sender;
- (IBAction)subscribe:(id)sender;

@end
