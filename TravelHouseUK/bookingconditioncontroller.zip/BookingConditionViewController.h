//
//  BookingConditionViewController.h
//  TravelHouseUK
//
//  Created by AR on 06/01/2014.
//
//

#import <UIKit/UIKit.h>

@interface BookingConditionViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIScrollView *bgScroller;
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *borderedlayer;

- (IBAction)goback:(id)sender;
- (IBAction)subscribe:(id)sender;

@end
